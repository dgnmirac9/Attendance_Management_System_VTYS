package com.example.c_lens_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
