#import <Flutter/Flutter.h>

@interface TfliteFlutterPlugin : NSObject<FlutterPlugin>
@end
